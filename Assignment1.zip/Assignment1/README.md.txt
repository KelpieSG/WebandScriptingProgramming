Reference:

https://www.w3schools.com/howto/howto_css_responsive_form.asp
https://www.w3schools.com/html/html_images.asp
https://www.w3schools.com/tags/att_video_poster.asp

Link to Website: https://fengpanassignment1.tiiny.site/index.html
